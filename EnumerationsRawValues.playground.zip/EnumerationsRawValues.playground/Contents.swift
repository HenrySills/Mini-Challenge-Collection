import UIKit

enum StatusCode: Int {
    case success = 200
    case unauthorized = 401
    case forbidden = 402
    case notFound = 403
}

func prettyPrint(code: StatusCode) -> String{
    switch code{
    case .success:
        return (String(StatusCode.success.rawValue) + " Success")

    case .unauthorized:
        return (String(StatusCode.success.rawValue) + " Unauthorized")
      
    case .forbidden:
        return (String(StatusCode.success.rawValue) + " Forbidden")
      
    case .notFound:
        return (String(StatusCode.success.rawValue) + " Not Found")
    
    }
    
}

prettyPrint(code: .success)

StatusCode.success.rawValue
