import UIKit


public class dog {
    
    let name: String
    let owner: String
    let age: Int
    let dogTag: String
    
    init(name: String, owner: String, age: Int) {
        self.name = "Orion"
        self.owner = "Shawn"
        self.age = 1
        self.dogTag = "If lost, call " + owner
    }
    
    func bark() {
        print ("Woof")
    }
}

let puppy = dog(name: "Orion", owner: "Shawn", age: 1)

puppy.bark() //This didn't give me the output I wanted, but the function shows that it does print "Woof"

print(puppy.dogTag)




//Random trial and error below


//puppy.bark() // Prints "Woof"

/*
class dog{
    var name: String
    var owner: String
    var age: Int

    
    init(owner: String) {
        return
        //self.owner
    }

    init(name: String) {
        //self.name = name
    }
    
    init(age: Int) {
        //self.age = age
    }
 
}


var student = (name: String, age: Int)("David", 17)
print(type(of: student)) // (String, Int)

 
 print("If lost call, '\(dog.owner)'"
*/
